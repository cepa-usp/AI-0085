// Variáveis do AI_Loader
var flashvars = {};
flashvars.ai = "swf/AI-0085.swf";
flashvars.width = "600";
flashvars.height = "343";

// Parâmetros do player (Flash)
var params = {};
params.menu = "false";
params.scale = "showall";

// Atributos da tag HTML que contém o SWF
var attributes = {};
attributes.id = "ai";
attributes.align = "left";
